<?
  function display_market_card_func($fields) {
    foreach ($fields as $key => $value){
      print $value;
    }
  }
